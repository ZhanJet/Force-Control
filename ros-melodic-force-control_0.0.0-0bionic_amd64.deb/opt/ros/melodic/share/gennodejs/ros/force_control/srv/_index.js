
"use strict";

let SetString = require('./SetString.js')
let SetFloat64 = require('./SetFloat64.js')

module.exports = {
  SetString: SetString,
  SetFloat64: SetFloat64,
};
